package br.ufac.bsi.tesi.academico.logic;

public class Centro {

	private String sigla;
	private String nome;

	public String getSigla() {
		return sigla;
	}
	public String getNome() {
		return nome;
	}
	public void setSigla(String sigla) {
		this.sigla = sigla;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	
	public String toString(){
		return this.nome;
	}
	
}
